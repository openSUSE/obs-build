# OpenWRT HelloWorld package

This is a OpenWRT package written in C++ using UClibc++ and CMake.

#### Build instructions
If the package is placed in qsdk/packages/helloworld, the following is used to compile it.
```sh
$ cd qsdk
$ make packages/helloworld/compile V=s
```

