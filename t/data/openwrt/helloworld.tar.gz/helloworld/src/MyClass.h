#ifndef MYCLASS_H
#define MYCLASS_H


class MyClass
{
public:
	MyClass();

	void printMessage();
};

#endif // MYCLASS_H
